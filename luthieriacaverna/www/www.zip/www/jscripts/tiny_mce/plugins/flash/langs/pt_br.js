/**
 * pt_br lang variables
 * Brazilian Portuguese
 *
 * Authors : ????
 * Revision and modifications:
 *           Marcio Barbosa (mpg) <mpg@mpg.com.br>
 * Last Updated : November 26, 2005
 * TinyMCE Version : 2.0RC4
 */
tinyMCE.addToLang('flash',{
title : 'Inserir / editar Arquivo Flash',
desc : 'Inserir / editar Arquivo Flash',
file : 'Arquivo Flash (.swf)',
size : 'Tamanho',
list : 'Lista de arquivos Flash',
props : 'Propriedades do Flash',
general : 'Geral'
});
