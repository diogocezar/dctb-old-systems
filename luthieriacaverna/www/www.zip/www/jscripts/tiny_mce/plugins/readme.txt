This is the location you place TinyMCE plugins.
