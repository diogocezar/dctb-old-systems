/**
* Variaveis para gerenciamento
*/

var idItens    = 'id_items';
var idDetalhes = 'id_detalhes';	



