<?
echo "<script language=javascript>location.href='./php/index.php';</script>";
?>