DROP TABLE EMPLOYEE;
CREATE TABLE EMPLOYEE 
(
  EMP_NO	SMALLINT NOT NULL,
  FIRST_NAME	VARCHAR(15) NOT NULL,
  LAST_NAME	VARCHAR(20) NOT NULL,
  PHONE_EXT	VARCHAR(4),
  DEPT_NO	CHAR(3) NOT NULL,
  JOB_CODE	VARCHAR(5) NOT NULL,
  JOB_GRADE	SMALLINT NOT NULL,
  JOB_COUNTRY	VARCHAR(15) NOT NULL,
  SALARY	NUMERIC(15,2) NOT NULL,
 PRIMARY KEY (EMP_NO)
);
INSERT INTO employee VALUES (2, 'Robert', 'Nelson', 
'250', '600', 'VP', 2, 
'USA', 105900.00);
INSERT INTO employee VALUES (4, 'Bruce', 'Young', 
'233', '621', 'Eng', 2, 
'USA', 97500.00);
INSERT INTO employee VALUES (5, 'Kim', 'Lambert', 
'22', '130', 'Eng', 2, 
'USA', 102750.00);
INSERT INTO employee VALUES (8, 'Leslie', 'Johnson', 
'410', '180', 'Mktg', 3, 
'USA', 64635.00);
INSERT INTO employee VALUES (9, 'Phil', 'Forest', 
'229', '622', 'Mngr', 3, 
'USA', 75060.00);
INSERT INTO employee VALUES (11, 'K. J.', 'Weston', 
'34', '130', 'SRep', 4, 
'USA', 86292.94);
INSERT INTO employee VALUES (12, 'Terri', 'Lee', 
'256', '000', 'Admin', 4, 
'USA', 53793.00);
INSERT INTO employee VALUES (14, 'Stewart', 'Hall', 
'227', '900', 'Finan', 3, 
'USA', 69482.62);
INSERT INTO employee VALUES (15, 'Katherine', 'Young', 
'231', '623', 'Mngr', 3, 
'USA', 67241.25);
INSERT INTO employee VALUES (20, 'Chris', 'Papadopoulos', 
'887', '671', 'Mngr', 3, 
'USA', 89655.00);
INSERT INTO employee VALUES (24, 'Pete', 'Fisher', 
'888', '671', 'Eng', 3, 
'USA', 81810.19);
INSERT INTO employee VALUES (28, 'Ann', 'Bennet', 
'5', '120', 'Admin', 5, 
'England', 22935.00);
INSERT INTO employee VALUES (29, 'Roger', 'De Souza', 
'288', '623', 'Eng', 3, 
'USA', 69482.62);
INSERT INTO employee VALUES (34, 'Janet', 'Baldwin', 
'2', '110', 'Sales', 3, 
'USA', 61637.81);
INSERT INTO employee VALUES (36, 'Roger', 'Reeves', 
'6', '120', 'Sales', 3, 
'England', 33620.62);
INSERT INTO employee VALUES (37, 'Willie', 'Stansbury', 
'7', '120', 'Eng', 4, 
'England', 39224.06);
INSERT INTO employee VALUES (44, 'Leslie', 'Phong', 
'216', '623', 'Eng', 4, 
'USA', 56034.38);
INSERT INTO employee VALUES (45, 'Ashok', 'Ramanathan', 
'209', '621', 'Eng', 3, 
'USA', 80689.50);
INSERT INTO employee VALUES (46, 'Walter', 'Steadman', 
'210', '900', 'CFO', 1, 
'USA', 116100.00);
INSERT INTO employee VALUES (52, 'Carol', 'Nordstrom', 
'420', '180', 'PRel', 4, 
'USA', 42742.50);
INSERT INTO employee VALUES (61, 'Luke', 'Leung', 
'3', '110', 'SRep', 4, 
'USA', 68805.00);
INSERT INTO employee VALUES (65, 'Sue Anne', 'O Brien', 
'877', '670', 'Admin', 5, 
'USA', 31275.00);
INSERT INTO employee VALUES (71, 'Jennifer M.', 'Burbank', 
'289', '622', 'Eng', 3, 
'USA', 53167.50);
INSERT INTO employee VALUES (72, 'Claudia', 'Sutherland', 
'null', '140', 'SRep', 4, 
'Canada', 100914.00);
INSERT INTO employee VALUES (83, 'Dana', 'Bishop', 
'290', '621', 'Eng', 3, 
'USA', 62550.00);
INSERT INTO employee VALUES (85, 'Mary S.', 'MacDonald', 
'477', '100', 'VP', 2, 
'USA', 111262.50);
INSERT INTO employee VALUES (94, 'Randy', 'Williams', 
'892', '672', 'Mngr', 4, 
'USA', 56295.00);
INSERT INTO employee VALUES (105, 'Oliver H.', 'Bender', 
'255', '000', 'CEO', 1, 
'USA', 212850.00);
INSERT INTO employee VALUES (107, 'Kevin', 'Cook', 
'894', '670', 'Dir', 2, 
'USA', 111262.50);
INSERT INTO employee VALUES (109, 'Kelly', 'Brown', 
'202', '600', 'Admin', 5, 
'USA', 27000.00);
INSERT INTO employee VALUES (110, 'Yuki', 'Ichida', 
'22', '115', 'Eng', 3, 
'Japan', 6000000.00);
INSERT INTO employee VALUES (113, 'Mary', 'Page', 
'845', '671', 'Eng', 4, 
'USA', 48000.00);
INSERT INTO employee VALUES (114, 'Bill', 'Parker', 
'247', '623', 'Eng', 5, 
'USA', 35000.00);
INSERT INTO employee VALUES (118, 'Takashi', 'Yamamoto', 
'23', '115', 'SRep', 4, 
'Japan', 7480000.00);
INSERT INTO employee VALUES (121, 'Roberto', 'Ferrari', 
'1', '125', 'SRep', 4, 
'Italy', 99000000.00);
INSERT INTO employee VALUES (127, 'Michael', 'Yanowski', 
'492', '100', 'SRep', 4, 
'USA', 44000.00);
INSERT INTO employee VALUES (134, 'Jacques', 'Glon', 
'null', '123', 'SRep', 4, 
'France', 390500.00);
INSERT INTO employee VALUES (136, 'Scott', 'Johnson', 
'265', '623', 'Doc', 3, 
'USA', 60000.00);
INSERT INTO employee VALUES (138, 'T.J.', 'Green', 
'218', '621', 'Eng', 4, 
'USA', 36000.00);
INSERT INTO employee VALUES (141, 'Pierre', 'Osborne', 
'null', '121', 'SRep', 4, 
'Switzerland', 110000.00);
INSERT INTO employee VALUES (144, 'John', 'Montgomery', 
'820', '672', 'Eng', 5, 
'USA', 35000.00);
INSERT INTO employee VALUES (145, 'Mark', 'Guckenheimer', 
'221', '622', 'Eng', 5, 
'USA', 32000.00);
