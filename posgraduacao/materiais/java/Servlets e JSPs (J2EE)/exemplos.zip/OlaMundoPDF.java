package testepdf;

import java.io.*;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

public class OlaMundoPDF {
    
public static void main(String args[]) throws IOException, DocumentException {
    // criar arquivo para sa�da
    FileOutputStream arq1 = new FileOutputStream("olamundo.pdf");
    
    // criar documento
    Document doc = new Document();
    
    // relacionar documento com stream
    PdfWriter docWriter = PdfWriter.getInstance(doc, arq1);
    
    // abrir e adicionar elementos ao arquivo
    doc.open();
    
    Paragraph p = new Paragraph("Ola Mundo em PDF");
    doc.add(p);
    
    // fechar documento
    doc.close();
    arq1.close();
}
    
}
