package beans;

import java.sql.*;
import java.util.*;

public class EmployeeDAO {
    
    private Connection con;
    private Statement stmt1;
    
/** Creates a new instance of EmployeeDAO */
public EmployeeDAO() {
    try {
        Class.forName("org.postgresql.Driver");
        String url = "jdbc:postgresql://172.26.10.10/employee";
        String usuario = "postgres";
        String senha = "postgres";
        this.con = DriverManager.getConnection(url, usuario, senha);
        this.stmt1 = this.con.createStatement();
    } catch (Exception e1) {
        System.out.println(e1.toString());
    }
}

public void finalize() {
    try {
        this.con.close();
    } catch (Exception e2) {}
}

public Employee find(int emp_no) {
    try {
        ResultSet rs = this.stmt1.executeQuery("select * from employee where emp_no ="+emp_no);
        if (rs.next()) {
            Employee resp = new Employee();
            resp.setEmp_no(emp_no);
            resp.setFirst_name(rs.getString("first_name"));
            resp.setLast_name(rs.getString("last_name"));
            resp.setPhone_ext(rs.getString("phone_ext"));
            resp.setJob_code(rs.getString("job_code"));
            resp.setJob_country(rs.getString("job_country"));
            resp.setJob_grade(rs.getInt("job_grade"));
            resp.setSalary(rs.getDouble("salary"));
            resp.setDept_no(rs.getString("dept_no"));
            return resp;
        } else {
            return null;
        }
    } catch (SQLException sql1) {
        System.out.println("Find:"+sql1.toString());
        return null;
    }

}    
//public void save(Employee e1)     {}

//public Collection listAll() {}
public Collection listAll() {
    try {
        ArrayList result = new ArrayList();
        ResultSet rs = this.stmt1.executeQuery("select * from employee order by emp_no");
        while (rs.next()) {
            Employee novo = new Employee();
            novo.setEmp_no(rs.getInt("emp_no"));
            novo.setFirst_name(rs.getString("first_name"));
            novo.setLast_name(rs.getString("last_name"));
            novo.setPhone_ext(rs.getString("phone_ext"));
            novo.setDept_no(rs.getString("dept_no"));
            novo.setJob_code(rs.getString("job_code"));
            novo.setJob_grade(rs.getInt("job_grade"));
            novo.setJob_country(rs.getString("job_country"));
            novo.setSalary(rs.getDouble("salary"));
            result.add(novo);
        }
        return result;
    } catch (SQLException sql2) {
        return null;
    }
}

    
}
