package testepdf;

import java.io.*;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
import java.sql.*;

public class ListaEmployeePdf {
    
public static void main(String args[]) throws Exception {
    
    // carregar driver
    Class.forName("org.postgresql.Driver");

    // obter conexao
    String url = "jdbc:postgresql://172.26.10.10/employee";
    String usuario = "postgres";
    String senha = "postgres";
    Connection con = DriverManager.getConnection(url, usuario, senha);
    
    // criar statement
    Statement stmt = con.createStatement();
    
    // criar arquivo para sa�da
    FileOutputStream arq1 = new FileOutputStream("listaemp.pdf");
    
    // criar documento
    Document doc = new Document();
    
    // relacionar documento com stream
    PdfWriter docWriter = PdfWriter.getInstance(doc, arq1);
    
    // abrir e adicionar elementos ao arquivo
    doc.open();
    
    Paragraph p = new Paragraph("Lista de Funcionarios");
    doc.add(p);
    
    ResultSet rs = stmt.executeQuery("select emp_no, first_name, last_name, salary from employee");
    while (rs.next()) {
        p = new Paragraph(rs.getString(1)+" - "+rs.getString(2)+" "+rs.getString(3)+" - "+rs.getString(4));
        doc.add(p);
    }
    
    // fechar documento
    doc.close();
    arq1.close();
    rs.close();
    stmt.close();
    con.close();
}
    
}
