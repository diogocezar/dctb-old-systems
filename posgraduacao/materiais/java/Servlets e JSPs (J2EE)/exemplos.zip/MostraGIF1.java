package paginas;

import java.io.*;
import java.net.*;
import java.sql.*;

import javax.servlet.*;
import javax.servlet.http.*;

/**
 *
 * @author leandro
 * @version
 */
public class MostraGIF1 extends HttpServlet {
    
    private Connection con;
    
    public void init() {
        try {
            // carregar driver
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e1) {}
        try {
            // obter conexao
            String url = "jdbc:postgresql://172.26.10.10/livraria";
            String usuario = "postgres";
            String senha = "postgres";
            this.con = DriverManager.getConnection(url, usuario, senha);
        } catch (SQLException sql1) {}
    }
    
    public void destroy() {
        try {
            this.con.close();
        } catch (SQLException sql2) {}
    }
    
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("image/gif");
        try {
            // criar statement
            Statement stmt;
            synchronized(this.con) {
                stmt = this.con.createStatement();
            }

            String livro_id = request.getParameter("id");
            if (livro_id == null) {
                livro_id = "1";
            }
            
            ByteArrayOutputStream buffer = new ByteArrayOutputStream(512);
            ResultSet rs = stmt.executeQuery("select capa from livros where livro_id = "+livro_id);
            if (rs.next()) {
                InputStream in = rs.getBinaryStream(1);
                int lido = 0;
                lido = in.read();
                while (lido>=0) {
                    buffer.write(lido);
                    lido = in.read();
                }
                // descarrega o buffer no output stream do servlet
                buffer.writeTo(response.getOutputStream());
            }
            
            rs.close();
            stmt.close();
        } catch (SQLException sql1) {
            log(sql1.toString());
        }
    }
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
