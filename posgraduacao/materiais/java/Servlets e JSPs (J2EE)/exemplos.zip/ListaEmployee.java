package testedb;

import java.sql.*;

public class ListaEmployee {
    
public static void main(String args[])  {
    // carregar driver
    try {
        Class.forName("org.postgresql.Driver");
    } catch (ClassNotFoundException e1) {
        System.out.println("Driver nao encontrado");
        System.exit(0);
    }
    try {
        // obter conexao
        String url = "jdbc:postgresql://172.26.10.10/employee";
        String usuario = "postgres";
        String senha = "postgres";
        Connection con = DriverManager.getConnection(url, usuario, senha);
    
        // criar statement
        Statement stmt = con.createStatement();
    
        // executar query
        ResultSet rs = stmt.executeQuery("select * from employee");
        while (rs.next()) {
            System.out.print(rs.getString("emp_no")+" - ");
            System.out.println(rs.getString("first_name")+" "+rs.getString("last_name"));
        }
    
        // fechar recursos
        rs.close();
        stmt.close();
        con.close();
    
    } catch (SQLException sql1) {
        System.out.println("Erro: "+sql1);
    }
    
}
    
    
}
