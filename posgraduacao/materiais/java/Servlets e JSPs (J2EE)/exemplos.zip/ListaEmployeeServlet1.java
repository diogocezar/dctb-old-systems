/*
 * ListaEmployeeServlet1.java
 *
 * Created on 17 de Junho de 2006, 09:42
 */

package paginas;

import java.io.*;
import java.net.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

/**
 *
 * @author leandro
 * @version
 */
public class ListaEmployeeServlet1 extends HttpServlet {
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        try {
            // carregar driver
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e1) {}
        try {
            // obter conexao
            String url = "jdbc:postgresql://172.26.10.10/employee";
            String usuario = "postgres";
            String senha = "postgres";
            Connection con = DriverManager.getConnection(url, usuario, senha);
    
            // criar statement
            Statement stmt = con.createStatement();
        
        
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ListaEmployeeServlet1</title>");
            out.println("</head>");
            out.println("<body>");
            
            out.println("<h1>Lista de Funcion�rios</h1>");
            // executar query
            ResultSet rs = stmt.executeQuery("select employee.emp_no, employee.first_name, employee.last_name, department.department "+
                  "from employee, department where employee.dept_no = department.dept_no");
            while (rs.next()) {
               out.print(rs.getString(1)+" - ");
               out.print(rs.getString(2)+" "+rs.getString(3)+" - ");
               out.println(rs.getString(4)+"<br>");
            }
            
            rs.close();
            stmt.close();
            con.close();
            out.println("</body>");
            out.println("</html>");
            out.close();
        } catch (SQLException sql1) {
            // envia mensagem para o log do servidor
            log("Erro em servlet: "+sql1);
        }
    }
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
