package testedao;

import beans.*;
import java.util.*;

public class ListEmpDAO {
    
public static void main(String args[])    {
    EmployeeDAO dao01 = new EmployeeDAO();
    
    List resultado = (List) dao01.listAll();
    
    Iterator it = resultado.iterator();
    
    while (it.hasNext()) {
        Employee item = (Employee) it.next();
        System.out.println(item.getFull_name());
    }
    
    
}
    
}
