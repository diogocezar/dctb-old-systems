package beans;

public class testeDao1 {
    
public static void main(String args[]) {
    EmployeeDAO empDao1 = new beans.EmployeeDAO();
    
    Employee emp1 = empDao1.find(4);
    if (emp1 != null) {
        System.out.println(emp1.getFull_name());
    } else {
        System.out.println("funcionario nao encontrado!");
    }
}
    
}
