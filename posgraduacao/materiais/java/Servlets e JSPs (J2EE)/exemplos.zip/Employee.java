package beans;

public class Employee {
    
    // Transfer Object - Design Pattern
    // Utilizado no design patter DAO (Data Access Object)
    // tamb�m chamado de ValueObject

    private int emp_no;
    private String first_name;
    private String last_name;
    private String phone_ext;
    private String dept_no;
    private String job_code;
    private int job_grade;
    private String job_country;
    private double salary;
    private String full_name;
    
public Employee() {
}

    public int getEmp_no() {
        return emp_no;
    }

    public void setEmp_no(int emp_no) {
        this.emp_no = emp_no;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getPhone_ext() {
        return phone_ext;
    }

    public void setPhone_ext(String phone_ext) {
        this.phone_ext = phone_ext;
    }

    public String getDept_no() {
        return dept_no;
    }

    public void setDept_no(String dept_no) {
        this.dept_no = dept_no;
    }

    public String getJob_code() {
        return job_code;
    }

    public void setJob_code(String job_code) {
        this.job_code = job_code;
    }

    public int getJob_grade() {
        return job_grade;
    }

    public void setJob_grade(int job_grade) {
        this.job_grade = job_grade;
    }

    public String getJob_country() {
        return job_country;
    }

    public void setJob_country(String job_country) {
        this.job_country = job_country;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getFull_name() {
        return this.getFirst_name()+" "+this.getLast_name();
    }

    
}
