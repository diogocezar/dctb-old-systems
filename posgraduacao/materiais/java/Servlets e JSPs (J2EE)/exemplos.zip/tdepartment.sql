DROP TABLE DEPARTMENT;
CREATE TABLE DEPARTMENT 
(
  DEPT_NO		CHAR(3) NOT NULL,
  DEPARTMENT	VARCHAR(25) NOT NULL,
  HEAD_DEPT	CHAR(3),
  MNGR_NO		SMALLINT,
  BUDGET		NUMERIC(15,2) NOT NULL,
  LOCATION	VARCHAR(15) NOT NULL,
  PHONE_NO	VARCHAR(20) NOT NULL,
 PRIMARY KEY (DEPT_NO)
);
INSERT INTO department VALUES ('000', 'Corporate Headquarters', null, 
105, 1000000.00, 
'Monterey', '(408) 555-1234');
INSERT INTO department VALUES ('100', 'Sales and Marketing', '000', 
85, 2000000.00, 
'San Francisco', '(415) 555-1234');
INSERT INTO department VALUES ('600', 'Engineering', '000', 
2, 1100000.00, 
'Monterey', '(408) 555-1234');
INSERT INTO department VALUES ('900', 'Finance', '000', 
46, 400000.00, 
'Monterey', '(408) 555-1234');
INSERT INTO department VALUES ('180', 'Marketing', '100', 
null, 1500000.00, 
'San Francisco', '(415) 555-1234');
INSERT INTO department VALUES ('620', 'Software Products Div.', '600', 
null, 1200000.00, 
'Monterey', '(408) 555-1234');
INSERT INTO department VALUES ('621', 'Software Development', '620', 
null, 400000.00, 
'Monterey', '(408) 555-1234');
INSERT INTO department VALUES ('622', 'Quality Assurance', '620', 
9, 300000.00, 
'Monterey', '(408) 555-1234');
INSERT INTO department VALUES ('623', 'Customer Support', '620', 
15, 650000.00, 
'Monterey', '(408) 555-1234');
INSERT INTO department VALUES ('670', 'Consumer Electronics Div.', '600', 
107, 1150000.00, 
'Burlington, VT', '(802) 555-1234');
INSERT INTO department VALUES ('671', 'Research and Development', '670', 
20, 460000.00, 
'Burlington, VT', '(802) 555-1234');
INSERT INTO department VALUES ('672', 'Customer Services', '670', 
94, 850000.00, 
'Burlington, VT', '(802) 555-1234');
INSERT INTO department VALUES ('130', 'Field Office: East Coast', '100', 
11, 500000.00, 
'Boston', '(617) 555-1234');
INSERT INTO department VALUES ('140', 'Field Office: Canada', '100', 
72, 500000.00, 
'Toronto', '(416) 677-1000');
INSERT INTO department VALUES ('110', 'Pacific Rim Headquarters', '100', 
34, 600000.00, 
'Kuaui', '(808) 555-1234');
INSERT INTO department VALUES ('115', 'Field Office: Japan', '110', 
118, 500000.00, 
'Tokyo', '3 5350 0901');
INSERT INTO department VALUES ('116', 'Field Office: Singapore', '110', 
null, 300000.00, 
'singapore', '3 55 1234');
INSERT INTO department VALUES ('120', 'European Headquarters', '100', 
36, 700000.00, 
'London', '71 235-4400');
INSERT INTO department VALUES ('121', 'Field Office: Switzerland', '120', 
141, 500000.00, 
'Zurich', '1 211 7767');
INSERT INTO department VALUES ('123', 'Field Office: France', '120', 
134, 400000.00, 
'Cannes', '58 68 11 12');
INSERT INTO department VALUES ('125', 'Field Office: Italy', '120', 
121, 400000.00, 
'Milan', '2 430 39 39');
