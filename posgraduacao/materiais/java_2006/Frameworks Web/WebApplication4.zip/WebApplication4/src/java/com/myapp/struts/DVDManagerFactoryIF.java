package com.myapp.struts;

/*
 * This a factory for the DVDManger DAO
 */
public interface DVDManagerFactoryIF {

   public DVDManagerIF createDVDManager();
   
}
