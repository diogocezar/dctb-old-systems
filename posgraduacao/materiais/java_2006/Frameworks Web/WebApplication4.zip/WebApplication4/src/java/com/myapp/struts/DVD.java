package com.myapp.struts;

import java.io.Serializable;

/*
 * This a bean - and also a Value - or Data Transfer Object 
 */
public class DVD implements Serializable {

   private int id;
   private String title;
   
   public DVD() {
   }
   
   public DVD(int id, String title) {
      setId(id);
      setTitle(title);
   }
   
   public int getId() {
      return id;
   }

   public void setId(int id) {
      this.id = id;
   }

   public String getTitle() {
      return title;
   }

   public void setTitle(String title) {
      this.title = title;
   }

}
