package com.myapp.struts;

import javax.naming.*;
import javax.sql.DataSource;

/*
 * This is a factory for the DVDManager DAO.
 * It uses Tomcat's JNDI DataSource feature 
 */
public class TomcatDVDManagerFactory implements DatabaseDVDManagerFactoryIF {

   private DataSource dataSource;

   public TomcatDVDManagerFactory() throws DAOException {
      DataSource ds = null;      
      try {
         Context initCtx = new InitialContext();
         Context envCtx  = (Context) initCtx.lookup("java:comp/env");
         ds   = (DataSource) envCtx.lookup("jdbc/dao");
      } catch (NamingException e) {
         throw new DAOException("Tomcat JNDI setup failed", e);
      }
      this.dataSource = ds;
   }

   public DataSource getDataSource() {
      return dataSource;
   }

   public DVDManagerIF createDVDManager() {
      DatabaseDVDManager manager = new DatabaseDVDManager();
      manager.setDataSource(dataSource);
      return manager;
   }


}
