package com.myapp.struts;


import java.util.Collection;

/*
 * This is a Data Access Object (DAO)
 */
public interface DVDManagerIF {

   public void createDVD(int id, String title) throws DAOException;
   public void updateDVD(int id, String title) throws DAOException;
   public void deleteDVD(int id) throws DAOException;
   public DVD getDVD(int id) throws DAOException; 
   public Collection getAll() throws DAOException;
   public Collection findDVDTitle(String title) throws DAOException;
   
}
