package com.myapp.struts;

import javax.sql.DataSource;

/*
 * This is a factory for a DVDManager DAO using a database 
 */
public interface DatabaseDVDManagerFactoryIF extends DVDManagerFactoryIF {

   public DataSource getDataSource();

}
