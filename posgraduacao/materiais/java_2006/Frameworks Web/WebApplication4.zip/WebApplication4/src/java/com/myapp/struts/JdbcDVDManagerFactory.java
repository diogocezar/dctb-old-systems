package com.myapp.struts;

import java.io.PrintWriter;
import java.sql.*;
import javax.sql.DataSource;

/*
 * This is a factory for the DVDManager DAO. It uses plain JDBC calls
 */
public class JdbcDVDManagerFactory implements DatabaseDVDManagerFactoryIF {
    
    private DataSource dataSource;
    /**
     * Derby network server port ; default is 1527
     */
    private static int NETWORKSERVER_PORT=1527;
    public static final String DERBY_CLIENT_DRIVER = "org.apache.derby.jdbc.ClientDriver";
    private static final String DERBY_CLIENT_DS = "org.apache.derby.jdbc.ClientDataSource";
    
    private static final String DERBY_CLIENT_URL= "jdbc:derby://localhost:"+ NETWORKSERVER_PORT+"/Sistema;create=true";
    public JdbcDVDManagerFactory() throws DAOException {
        //    Load the DERB server JDBC driver
        String driverName = "org.apache.derby.jdbc.ClientDriver";
        try {
            Class.forName(DERBY_CLIENT_DRIVER);
        } catch (ClassNotFoundException e) {
            throw new DAOException("JDBC Driver " + driverName + " could not be loaded");
        }
        dataSource = new MyDataSource();
    }
    
    public DataSource getDataSource() {
        return dataSource;
    }
    
    public DVDManagerIF createDVDManager() {
        DatabaseDVDManager manager = new DatabaseDVDManager();
        manager.setDataSource(dataSource);
        return manager;
    }
    
    private class MyDataSource implements DataSource {
        
        public int getLoginTimeout() throws SQLException {
            return 0;
        }
        
        public void setLoginTimeout(int arg0) throws SQLException {
        }
        
        public PrintWriter getLogWriter() throws SQLException {
            return null;
        }
        
        public void setLogWriter(PrintWriter arg0) throws SQLException {
        }
        
        public Connection getConnection() throws SQLException {
            //    Create a connection to the database
           
            String username = "admin";
            String password = "admin";
            return DriverManager.getConnection(DERBY_CLIENT_URL, username, password);
        }
        
        public Connection getConnection(String arg0, String arg1) throws SQLException {
            return null;
        }
    }
    
}
