package com.myapp.struts;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

import javax.sql.DataSource;



public class DatabaseDVDManager implements DVDManagerIF {

   private DataSource dataSource;


   // Contains en Exception when an error has occured   
   private Exception error;
   // Contains an error message
   private String message;

   public void setDataSource(DataSource dataSource) {
      this.dataSource = dataSource;
   }

   public void createDVD(int id, String title) throws DAOException {
      if (getDVD(id) != null) throw new DAOException("Id " + id + " is already used");
      Connection conn = null;
      PreparedStatement pstmt = null;
      error = null;
      
      try {
         conn = dataSource.getConnection();
         
         
         // Prepare a statement to insert a record
         String sql = "INSERT INTO \"ADMIN\".\"dvd\" (\"id\", \"title\") VALUES(?, ?)";
         pstmt = conn.prepareStatement(sql);
         pstmt.setInt(1, id);
         pstmt.setString(2, title);
         pstmt.executeUpdate();
      } catch (SQLException e) {
         error = e;
         message = "Create failed";
      }

      closePrep(pstmt);
      closeConnection(conn);
      checkOK();               
   }

   public DVD getDVD(int id) throws DAOException {
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet result = null;
      error = null;
      DVD dvd = null;
      
      try {
         conn = dataSource.getConnection();
        
         // Prepare a statement to insert a record
         String sql = "SELECT * FROM \"ADMIN\".\"dvd\" WHERE \"id\"=?";
         pstmt = conn.prepareStatement(sql);
         pstmt.setInt(1, id);
         result = pstmt.executeQuery();
         if (result.next()) {
            int newId = result.getInt("id");
            String title = result.getString("title");
            dvd = new DVD(newId, title);
         }
      } catch (SQLException e) {
         error = e;
         message = "Read failed";
      }
   
      closeResult(result);
      closePrep(pstmt);
      closeConnection(conn);
      checkOK();       
      
      return dvd;        
   }

   public void updateDVD(int id, String title) throws DAOException {
      if (getDVD(id) == null) throw new DAOException("Id " + id + " was not found");
      Connection conn = null;
      PreparedStatement pstmt = null;
      error = null;
      
      try {
         conn = dataSource.getConnection();
        
         // Prepare a statement to update a record
         String sql = "UPDATE \"ADMIN\".\"dvd\" SET \"title\"=? WHERE \"id\"=?";
         pstmt = conn.prepareStatement(sql);
         pstmt.setString(1, title);
         pstmt.setInt(2, id);
         pstmt.executeUpdate();
      } catch (SQLException e) {
         error = e;
         message = "Update failed";
      }

      closePrep(pstmt);
      closeConnection(conn);
      checkOK();               
   }

   public void deleteDVD(int id) throws DAOException {
      if (getDVD(id) == null) throw new DAOException("Id " + id + " was not found");
      Connection conn = null;
      PreparedStatement pstmt = null;
      error = null;
      
      try {
         conn = dataSource.getConnection();
         
         // Prepare a statement to delete a record
         String sql = "DELETE FROM \"ADMIN\".\"dvd\" WHERE \"id\"=?";
         pstmt = conn.prepareStatement(sql);
         pstmt.setInt(1, id);
         pstmt.executeUpdate();
      } catch (SQLException e) {
         error = e;
         message = "Delete failed";
      }

      closePrep(pstmt);
      closeConnection(conn);
      checkOK();               
      
   }

   public Collection getAll() throws DAOException {
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      error = null;
      Collection c = new ArrayList();
      
      try {
         conn = dataSource.getConnection();
   
         // Prepare a statement to delete a record
         String sql = "SELECT * FROM \"ADMIN\".\"dvd\"";
         pstmt = conn.prepareStatement(sql);
         rs = pstmt.executeQuery();
         while (rs.next()) {
            int id = rs.getInt("id");
            String title = rs.getString("title");
            DVD dvd = new DVD(id, title);
            c.add(dvd);
         } 
      } catch (SQLException e) {
         error = e;
         message = "Getall failed";
      }

      closeResult(rs);
      closePrep(pstmt);
      closeConnection(conn);
      checkOK();               
      return c;
      
   }

   public Collection findDVDTitle(String findTitle) throws DAOException {
      Connection conn = null;
      PreparedStatement pstmt = null;
      ResultSet rs = null;
      error = null;
      Collection c = new ArrayList();
      
      try {
         conn = dataSource.getConnection();
  
         // Prepare a statement to delete a record
         String sql = "SELECT * FROM \"ADMIN\".\"dvd\"";
         pstmt = conn.prepareStatement(sql);
         rs = pstmt.executeQuery(sql);
         while (rs.next()) {
            int id = rs.getInt("id");
            String title = rs.getString("title");
            DVD dvd = new DVD(id, title);
            if (dvd.getTitle().toUpperCase().indexOf(findTitle.toUpperCase()) > -1) {
               c.add(dvd);
            }
         } 
      } catch (SQLException e) {
         error = e;
         message = "Find failed";
      }

      closeResult(rs);
      closePrep(pstmt);
      closeConnection(conn);
      checkOK();               
      return c;
      
   }
   
   private void checkOK() throws DAOException {
      if (error != null) {
         throw new DAOException(message, error);
      }
   }
   
   private void closeConnection(Connection connection) {
      if (connection != null) {
         try {
            connection.close();
         } catch (SQLException e) {
            if (error == null) {
               error = e;
               message = "Close conn failed";
            }
         }
      }
   }

   private void closePrep(PreparedStatement prep) {
      if (prep != null) {
         try {
            prep.close();
         } catch (SQLException e) {
            if (error == null) {
               error = e;
               message = "Close prep failed";
            }
         }
      }
   }
   
   private void closeResult(ResultSet rs) {
      if (rs != null) {
         try {
            rs.close();
         } catch (SQLException e) {
            if (error == null) {
               error = e;
               message = "Close result failed";
            }
         }
      }
   }

}
