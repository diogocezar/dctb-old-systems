/*
 * DVDFormBean.java
 *
 * Created on 12 de Julho de 2006, 23:09
 */

package com.myapp.struts;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

/**
 *
 * @author Edson
 * @version
 */

public class DVDFormBean extends org.apache.struts.action.ActionForm {
    
    private String title;
    
    private int id;
 
   

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getId() {
        return id;
    }

    public void setId(int idDvd) {
        this.id = idDvd;
    }
}
