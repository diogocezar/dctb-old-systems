/*
 * DVDAction.java
 *
 * Created on 12 de Julho de 2006, 23:06
 */

package com.myapp.struts;

import java.util.ArrayList;
import java.util.Collection;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.actions.DispatchAction;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;
/**
 *
 * @author Edson
 * @version
 */

public class DVDAction extends DispatchAction {
    
    /* forward name="success" path="" */
    private final static String SUCCESS = "success";
    
    private final static String LIST = "list";
    
    /**
     * This is the Struts action method called on
     * http://.../actionPath?method=myAction1,
     * where "method" is the value specified in <action> element :
     * ( <action parameter="method" .../> )
     */
    public ActionForward listar(ActionMapping mapping, ActionForm  form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        
        DVDManagerFactoryIF factory = new JdbcDVDManagerFactory();
        DVDManagerIF manager = factory.createDVDManager();
        Collection c = new ArrayList();
        
        try {
            c = manager.getAll();
        } catch (DAOException e) {
            
            // Save the chained exceptions:
            request.setAttribute("MYEXCEPTION", new DAOException("Erro na listagem ", e));
            
            // Return to the error page
            return (mapping.findForward("error"));
        }
        HttpSession session = request.getSession();
        session.setAttribute("dvds", c);
        return mapping.findForward(SUCCESS);
    }
    
    
    
    
    /**
     * This is the Struts action method called on
     * http://.../actionPath?method=myAction2,
     * where "method" is the value specified in <action> element :
     * ( <action parameter="method" .../> )
     */
    public ActionForward inserir(ActionMapping mapping, ActionForm  form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        DVDFormBean formBean = (DVDFormBean)form;
        DVDManagerFactoryIF factory = new JdbcDVDManagerFactory();
        DVDManagerIF manager = factory.createDVDManager();
        Collection c = new ArrayList();
        try {
            manager.createDVD(formBean.getId(),formBean.getTitle());
            c = manager.getAll();
        } catch (DAOException e) {
            e.printStackTrace();
            // Save the chained exceptions:
            request.setAttribute("MYEXCEPTION", new DAOException("Erro na inclus�o ", e));
            
            // Return to the error page
            return (mapping.findForward("error"));
        }
        
        
        HttpSession session = request.getSession();
        session.setAttribute("dvds", c);
        return mapping.findForward(SUCCESS);
    }
    
    /**
     * This is the Struts action method called on
     * http://.../actionPath?method=myAction2,
     * where "method" is the value specified in <action> element :
     * ( <action parameter="method" .../> )
     */
    public ActionForward exibir(ActionMapping mapping, ActionForm  form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        
        DVDFormBean formBean = (DVDFormBean)form;
        DVDManagerFactoryIF factory = new JdbcDVDManagerFactory();
        DVDManagerIF manager = factory.createDVDManager();
        DVD dvd = new DVD();
        
        try {
            dvd  = manager.getDVD(formBean.getId());
            
        } catch (DAOException e) {
            e.printStackTrace();
            // Save the chained exceptions:
            request.setAttribute("MYEXCEPTION", new DAOException("Erro na altera��o ", e));
            
            // Return to the error page
            return (mapping.findForward("error"));
        }
        
        formBean.setTitle(dvd.getTitle());
        return mapping.findForward(LIST);
    }
    
    
    /**
     * This is the Struts action method called on
     * http://.../actionPath?method=myAction2,
     * where "method" is the value specified in <action> element :
     * ( <action parameter="method" .../> )
     */
    public ActionForward alterar(ActionMapping mapping, ActionForm  form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        DVDFormBean formBean = (DVDFormBean)form;
        DVDManagerFactoryIF factory = new JdbcDVDManagerFactory();
        DVDManagerIF manager = factory.createDVDManager();
        Collection c = new ArrayList();
        try {
            manager.updateDVD(formBean.getId(),formBean.getTitle());
            c = manager.getAll();
        } catch (DAOException e) {
            e.printStackTrace();
            // Save the chained exceptions:
            request.setAttribute("MYEXCEPTION", new DAOException("Erro na altera��o ", e));
            
            // Return to the error page
            return (mapping.findForward("error"));
        }
        HttpSession session = request.getSession();
        session.setAttribute("dvds", c);
        return mapping.findForward(SUCCESS);
    }
    
    
    /**
     * This is the Struts action method called on
     * http://.../actionPath?method=myAction2,
     * where "method" is the value specified in <action> element :
     * ( <action parameter="method" .../> )
     */
    public ActionForward excluir(ActionMapping mapping, ActionForm  form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        DVDFormBean formBean = (DVDFormBean)form;
        DVDManagerFactoryIF factory = new JdbcDVDManagerFactory();
        DVDManagerIF manager = factory.createDVDManager();
        Collection c = new ArrayList();
        try {
            manager.deleteDVD(formBean.getId());
            c = manager.getAll();
        } catch (DAOException e) {
            e.printStackTrace();
            // Save the chained exceptions:
            request.setAttribute("MYEXCEPTION", new DAOException("Erro na exclus�o", e));
            
            // Return to the error page
            return (mapping.findForward("error"));
        }
        HttpSession session = request.getSession();
        session.setAttribute("dvds", c);
        
        return mapping.findForward(SUCCESS);
    }
}
