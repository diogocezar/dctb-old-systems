SAJAX PHP BACKEND
-----------------

Contributed and copyighted by Thomas Lackner and ModernMethod
(http://www.modernmethod.com/).


