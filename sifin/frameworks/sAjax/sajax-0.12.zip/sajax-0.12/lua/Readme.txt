SAJAX LUA BACKEND
-----------------

Contributed and copyighted by Javier Guerra (http://www.guerrag.com/).


