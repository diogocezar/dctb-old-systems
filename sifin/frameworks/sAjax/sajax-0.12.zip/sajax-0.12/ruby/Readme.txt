SAJAX RUBY BACKEND
------------------

Contributed and put into the public domain by an anonymous member
of the Sajax forum. If anyone wants to take control of this port
and improve it, it would be welcomed.



