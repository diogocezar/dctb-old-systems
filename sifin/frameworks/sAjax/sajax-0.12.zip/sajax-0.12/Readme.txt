WELCOME TO SAJAX
----------------

Sajax is a cross-platform, cross-browser web scripting toolkit
that makes it easy to expose functions in your code to JavaScript.

For more information about Sajax, please see the homepage:

	http://www.modernmethod.com/sajax/

In this archive you will find a folder for each platform that is
currently supported. Please see individual documentation in each
folder for specific errata.

