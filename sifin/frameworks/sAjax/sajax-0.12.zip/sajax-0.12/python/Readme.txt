SAJAX PYTHON BACKEND
--------------------

Contributed and copyighted by Adam Collard. Additional guidance and
consultation by Carlos Bueno.

IMPORTANT: This backend is NOT licensed under the BSD-L. It is licensed
under the Creative Commons "By" License version 2.0. Please see
License.txt for details. 
